# Copyright (c) 2025 AnonymousX1025
# Licensed under the MIT License.
# This file is part of AnonXMusic


import time
import asyncio

from pyrogram import enums, errors, filters, types

from anony import anon, app, config, db, lang, queue, tasks, userbot, yt
from anony.helpers import buttons


@app.on_message(filters.video_chat_started, group=19)
@app.on_message(filters.video_chat_ended, group=20)
async def _watcher_vc(_, m: types.Message):
    await anon.stop(m.chat.id)


async def auto_leave():
    while True:
        await asyncio.sleep(1800)
        for ub in userbot.clients:
            try:
                chats = [dialog.chat.id async for dialog in ub.get_dialogs()
                            if dialog.chat.type in [
                                enums.ChatType.GROUP, enums.ChatType.SUPERGROUP,
                            ]][-20:]
                for chat in chats:
                    if chat in [app.logger, -1001686672798, -1001549206010]:
                        continue
                    if chat in db.active_calls:
                        continue
                    await ub.leave_chat(chat)
                    await asyncio.sleep(5)
            except Exception:
                continue


async def track_time():
    while True:
        await asyncio.sleep(1)
        for chat_id in list(db.active_calls):
            if not await db.playing(chat_id):
                continue
            media = queue.get_current(chat_id)
            if not media:
                continue
            media.time += 1


async def update_timer(length=10):
    while True:
        await asyncio.sleep(7)
        for chat_id in list(db.active_calls):
            if not await db.playing(chat_id):
                continue
            try:
                media = queue.get_current(chat_id)
                duration, message_id = media.duration_sec, media.message_id
                if not duration or not message_id or not media.time:
                    continue
                played = media.time
                remaining = duration - played
                pos = min(int((played / duration) * length), length - 1)
                timer = "—" * pos + "◉" + "—" * (length - pos - 1)

                if remaining <= 30:
                    next = queue.get_next(chat_id, check=True)
                    if next and not next.file_path:
                        next.file_path = await yt.download(next.id, video=next.video)

                if remaining < 10:
                    remove = True
                else:
                    if config.THUMB_GEN:
                        timer = f"{time.strftime('%M:%S', time.gmtime(played))} | {timer} | -{time.strftime('%M:%S', time.gmtime(remaining))}"
                    else:
                        timer = None
                    remove = False

                if not timer and not remove:
                    continue

                await app.edit_message_reply_markup(
                    chat_id=chat_id,
                    message_id=message_id,
                    reply_markup=buttons.controls(
                        chat_id=chat_id, timer=timer, remove=remove
                    ),
                )
            except Exception:
                pass


async def vc_watcher(sleep=5):
    while True:
        await asyncio.sleep(sleep)
        for chat_id in list(db.active_calls):
            client = await db.get_assistant(chat_id)
            media = queue.get_current(chat_id)
            participants = await client.get_participants(chat_id)
            prev = await db.get_participants(chat_id)
            current = set()
            try:
                for p in (participants or []):
                    uid = None
                    if hasattr(p, "user") and getattr(p, "user"):
                        uid = getattr(p.user, "id", None)
                    elif hasattr(p, "user_id"):
                        uid = getattr(p, "user_id", None)
                    elif hasattr(p, "id"):
                        uid = getattr(p, "id", None)
                    if uid:
                        current.add(uid)
            except Exception:
                current = set()
            _lang = await lang.get_lang(chat_id)
            added = current - prev
            removed = prev - current
            if added:
                for uid in list(added)[:5]:
                    try:
                        user = await app.get_users(uid)
                        await app.send_message(chat_id=chat_id, text=_lang.get("vc_join", "{0} joined the voice chat 👋").format(user.mention))
                    except Exception:
                        pass
            if removed:
                for uid in list(removed)[:5]:
                    try:
                        user = await app.get_users(uid)
                        await app.send_message(chat_id=chat_id, text=_lang.get("vc_leave", "{0} left the voice chat 👋").format(user.mention))
                    except Exception:
                        pass
            await db.set_participants(chat_id, current)
            if len(current) == 1 and client.id in current:
                _lang = await lang.get_lang(chat_id)
                try:
                    sent = await app.edit_message_reply_markup(
                        chat_id=chat_id,
                        message_id=media.message_id,
                        reply_markup=buttons.controls(
                            chat_id=chat_id, status=_lang["stopped"], remove=True
                        ),
                    )
                    await anon.stop(chat_id)
                    await app.send_message(chat_id=chat_id, text=_lang["auto_left"])
                except errors.MessageIdInvalid:
                    pass
            if len(participants) < 2 and media.time > 30:
                _lang = await lang.get_lang(chat_id)
                try:
                    sent = await app.edit_message_reply_markup(
                        chat_id=chat_id,
                        message_id=media.message_id,
                        reply_markup=buttons.controls(
                            chat_id=chat_id, status=_lang["stopped"], remove=True
                        ),
                    )
                    await anon.stop(chat_id)
                    await sent.reply_text(_lang["auto_left"])
                except errors.MessageIdInvalid:
                    pass


async def auto_cleanup_cache():
    import os
    import time
    import shutil
    interval = getattr(config, "CLEANUP_INTERVAL", 3600)
    max_age = getattr(config, "CLEANUP_AGE_HOURS", 6) * 3600
    while True:
        await asyncio.sleep(interval)
        try:
            in_use = set()
            for chat_id in list(db.active_calls):
                media = queue.get_current(chat_id)
                if media and media.file_path:
                    in_use.add(os.path.abspath(media.file_path))
                for item in queue.get_queue(chat_id):
                    if hasattr(item, "file_path") and item.file_path:
                        in_use.add(os.path.abspath(item.file_path))

            now = time.time()
            for d in ("cache", "downloads", "__pycache__"):
                if not os.path.isdir(d):
                    continue
                for root, dirs, files in os.walk(d):
                    for fname in files:
                        fpath = os.path.abspath(os.path.join(root, fname))
                        try:
                            st = os.stat(fpath)
                            if (now - st.st_mtime) > max_age and fpath not in in_use:
                                os.remove(fpath)
                        except Exception:
                            continue
                    # Remove empty directories
                    for dirname in dirs:
                        dirpath = os.path.join(root, dirname)
                        try:
                            if not os.listdir(dirpath):
                                shutil.rmtree(dirpath, ignore_errors=True)
                        except Exception:
                            pass
        except Exception:
            pass

tasks.append(asyncio.create_task(vc_watcher()))
if config.AUTO_LEAVE:
    tasks.append(asyncio.create_task(auto_leave()))
tasks.append(asyncio.create_task(track_time()))
tasks.append(asyncio.create_task(update_timer()))
tasks.append(asyncio.create_task(auto_cleanup_cache()))
