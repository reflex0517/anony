# Copyright (c) 2025 AnonymousX1025
# Licensed under the MIT License.
# This file is part of AnonXMusic


import os
import aiohttp
from PIL import (Image, ImageDraw, ImageEnhance,
                 ImageFilter, ImageFont, ImageOps)

from anony import config, app
from anony.helpers import Track


class Thumbnail:
    def __init__(self):
        self.rect = (914, 514)
        self.fill = (255, 255, 255)
        self.mask = Image.new("L", self.rect, 0)
        try:
            self.font1 = ImageFont.truetype("anony/helpers/Raleway-Bold.ttf", 34)
        except Exception:
            self.font1 = ImageFont.load_default()
        try:
            self.font2 = ImageFont.truetype("anony/helpers/Inter-Light.ttf", 28)
        except Exception:
            self.font2 = ImageFont.load_default()

    async def save_thumb(self, output_path: str, url: str) -> str:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                open(output_path, "wb").write(await resp.read())
            return output_path

    async def generate(self, song: Track, size=(1280, 720)) -> str:
        try:
            temp = f"cache/temp_{song.id}.jpg"
            output = f"cache/{song.id}.png"
            if os.path.exists(output):
                return output

            await self.save_thumb(temp, song.thumbnail)
            thumb = Image.open(temp).convert("RGBA").resize(size, Image.Resampling.LANCZOS)
            blur = thumb.filter(ImageFilter.GaussianBlur(18))
            image = ImageEnhance.Brightness(blur).enhance(.45)

            # Gradient overlay for modern look
            grad = Image.new("RGBA", size, (0, 0, 0, 0))
            gdraw = ImageDraw.Draw(grad)
            for i in range(size[1]):
                alpha = int(140 * (i / size[1]))
                gdraw.line([(0, i), (size[0], i)], fill=(25, 25, 35, alpha))
            image = Image.alpha_composite(image, grad)

            _rect = ImageOps.fit(thumb, self.rect, method=Image.LANCZOS, centering=(0.5, 0.5))
            ImageDraw.Draw(self.mask).rounded_rectangle((0, 0, self.rect[0], self.rect[1]), radius=15, fill=255)
            _rect.putalpha(self.mask)
            image.paste(_rect, (183, 30), _rect)

            draw = ImageDraw.Draw(image)
            # Text shadow for better readability
            def shadow_text(xy, text, font, fill=(255,255,255), shadow=(0,0,0)):
                sx, sy = xy
                draw.text((sx+2, sy+2), text, font=font, fill=shadow)
                draw.text((sx, sy), text, font=font, fill=fill)

            shadow_text((50, 40), f"{app.name}", self.font2, self.fill)
            ch = (song.channel_name or "")[:25]
            vc = song.view_count or ""
            tl = (song.title or "")[:52]
            shadow_text((50, 560), f"👤 {ch}  •  👁 {vc}", self.font2, self.fill)
            shadow_text((50, 600), f"🎵 {tl}", self.font1, self.fill)
            shadow_text((40, 650), "00:00", self.font1, self.fill)
            # Progress bar baseline
            draw.rounded_rectangle([(140, 666), (1160, 674)], radius=4, fill=(255,255,255,220))
            shadow_text((1185, 650), song.duration or "00:00", self.font1, self.fill)

            image.save(output)
            os.remove(temp)
            return output
        except Exception:
            return config.DEFAULT_THUMB
